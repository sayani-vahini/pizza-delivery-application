import React from 'react';
import Navbar from '../../Components/Navbar/Navbar';
import Orders from '../../Components/Orders/Orders';
export default function CartScreen() {
	return (
		<div>
			<Navbar />
			<Orders />
		</div>
	);
}
